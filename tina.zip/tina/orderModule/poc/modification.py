# creating the prompt
from .ordering_json import prompt_gen, api_call
import json

def get_modification_list(transcript):
    prompt = prompt_gen(transcript, "poc/data/prompt_update_list.txt")
    r = api_call(prompt)
    r = json.loads(r)
    print(r)
    r = r['choices'][0]['message']['content']
    r = r.replace('\n', '').rstrip(',')
    try :
        data_json = json.loads('[' + r + ']')
    except:
        data_json = 'False'

    return data_json


def apply_modifications(original_list, modification_list):
    for modifications in modification_list:
        for modification in modifications['modifications']:
            name = modification['name'].strip()
            type_modification = modification['type_modification']
            quantity = modification['quantity']
            for item in original_list:
                if item['name'].strip() == name:
                    if type_modification == 'addition':
                        current_quantity = int(item['quantity'].split()[0])
                        new_quantity = current_quantity + quantity
                        item['quantity'] = str(new_quantity) + ' ' + item['quantity'].split()[1]
                    elif type_modification == 'modification':
                        current_quantity = int(item['quantity'].split()[0])
                        new_quantity = current_quantity + quantity
                        item['quantity'] = str(new_quantity) + ' ' + item['quantity'].split()[1]
                    elif type_modification == 'suppression':
                        original_list.remove(item)
                    break
            else:
                if type_modification == 'addition':
                    original_list.append({
                        'id': str(len(original_list) + 1),
                        'name': name,
                        'quantity': quantity,
                        'type': modification['type']
                    })
    return original_list
