from speech_to_text import speech_to_text, clean_response
from orderModule.poc.ordering_json import get_json_products
from levenshtein_distance import data_cleaning
from get_vocabulaire import extract_vocabular
DEEPGRAM_API_KEY = "df4058e318edaa20733dc64e112f0d5c8a8fea60"

PATH_TO_FILE = "data/voice/Sami.m4a"
res = speech_to_text(PATH_TO_FILE,DEEPGRAM_API_KEY)

transcript = clean_response(res)
ress = get_json_products(transcript)
v = extract_vocabular("data/products.csv")
clean = data_cleaning(ress,v)
for item in clean:
    print(item["name"]+"-")
