import pandas as pd
import re
from fuzzywuzzy import process


def get_name(row):
    parts = re.split(r'(\d+)', row["name"])
    return parts[0]

def extract_vocabular(products_file):
    filepath = products_file
    products = pd.read_csv(filepath, delimiter = ";")
    products["racine"] = products.apply(get_name, axis=1)
    vocabulaire = products.racine.unique()
    return vocabulaire