import pandas as pd
import re
from fuzzywuzzy import process


def data_cleaning(list_product_precleaned,vocabulaire):
    print(list_product_precleaned)
    try :
        list_product_clean = list_product_precleaned[0]["items"]
        for product in list_product_clean:
            product["name"] = process.extractOne(product["name"], vocabulaire)[0]
    except:
        list_product_clean = list_product_precleaned
        for product in list_product_clean:
            product["name"] = process.extractOne(product["name"], vocabulaire)[0]
    return list_product_clean

def modification_cleaning(modifications,vocabulaire):
    for modification in modifications[0]['modifications']:
        modification['name'] = process.extractOne(modification['name'], vocabulaire)[0]
    return modifications