from gtts import gTTS
import os

def text_to_speech(text, language='en'):
    tts = gTTS(text=text, lang=language)
    filename = "output.mp3"
    tts.save(filename)
    return filename
