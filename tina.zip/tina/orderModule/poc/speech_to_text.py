from deepgram import DeepgramClient, PrerecordedOptions
import json


DEEPGRAM_API_KEY = "df4058e318edaa20733dc64e112f0d5c8a8fea60"

def speech_to_text(input_audio, DEEPGRAM_API_KEY):
    deepgram = DeepgramClient(DEEPGRAM_API_KEY)

    with open(input_audio, 'rb') as buffer_data:
        payload = { 'buffer': buffer_data }

        options = PrerecordedOptions(
            smart_format=True, model="nova-2",language="en"
        )

        print('Requesting transcript...')
        print('Your file may take up to a couple minutes to process.')
        print('While you wait, did you know that Deepgram accepts over 40 audio file formats? Even MP4s.')
        print('To learn more about customizing your transcripts check out developers.deepgram.com')

        response = deepgram.listen.prerecorded.v('1').transcribe_file(payload, options)
        return response.to_json(indent=4)


def clean_response(raw):
    transcript = json.loads(raw)
    transcript = transcript["results"]["channels"][0]["alternatives"][0]["transcript"]
    return transcript

