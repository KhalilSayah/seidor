import requests
import json


def prompt_gen(transcript, o_prompt):
    fichier = open(o_prompt, 'r')
    raw_prompt = fichier.read()
    final_prompt = raw_prompt + transcript

    return final_prompt


def api_call(prompt):
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer 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"
    }

    data = {
        "model": "gpt-3.5-turbo",
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.7
    }

    r = requests.post("https://api.openai.com/v1/chat/completions", headers=headers, json=data)

    return r.text

def text_cleaning(raw_response):

    res = json.loads(raw_response)

    result = json.loads(res['choices'][0]['message']['content'])

    return result


def get_json_products(transcript):
    final_prompt = prompt_gen(transcript,"poc/data/prompt_get_list.txt")
    r = api_call(final_prompt)
    r = json.loads(r)
    r = r['choices'][0]['message']['content']
    r = r.replace('\n', '').rstrip(',')
    data_json = json.loads('[' + r + ']')
    return data_json
