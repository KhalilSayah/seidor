import json

from fastapi import FastAPI, UploadFile
import os
from fastapi.responses import JSONResponse
from poc.speech_to_text import speech_to_text, clean_response
from poc.levenshtein_distance import data_cleaning,modification_cleaning
from poc.get_vocabulaire import extract_vocabular
from poc.modification import get_modification_list, apply_modifications
from poc.ordering_json import get_json_products

app = FastAPI()
storage_folder = "tmp"
DEEPGRAM_API_KEY = "a0301c6cbbbcd568e835de9955e3b96b2925bf1c"

@app.get("/")
def read_root():
    return {"Hello": "World"}

@app.post("/order/")
async def audio_to_order(file : UploadFile):
    if not os.path.exists(storage_folder):
        os.makedirs(storage_folder)

    file_path = os.path.join(storage_folder, file.filename.split("/")[-1])
    print(file_path)

    with open(file_path, "wb") as buffer:
        buffer.write(await file.read())

    res = speech_to_text(file_path, DEEPGRAM_API_KEY)

    transcript = clean_response(res)
    ress = get_json_products(transcript)
    v = extract_vocabular("poc/data/products.csv")
    clean = data_cleaning(ress, v)
    return JSONResponse(content=clean, status_code=200)


@app.post("/updateorder/")
async def update_order(file : UploadFile, old_order: list):
    print("----here---")
    old_order = [json.loads(item.replace("'", '"')) for item in old_order]
    print("---and then here----")
    if not os.path.exists(storage_folder):
        os.makedirs(storage_folder)

    file_path = os.path.join(storage_folder, file.filename.split("/")[-1])
    print("################# File path ###############")

    print(file_path)
    with open(file_path, "wb") as buffer:
        buffer.write(await file.read())

    res = speech_to_text(file_path, DEEPGRAM_API_KEY)
    transcript = clean_response(res)
    print("############")

    ress = get_modification_list(transcript)
    print(ress)
    v = extract_vocabular("poc/data/products.csv")


    print("****************")
    print(old_order)
    print("****************")

    if str(ress) == "False" :
        # Afficher la list
        print("we are in false close")
        ress = old_order
        get_list(ress)
        return old_order
    else:
        ress = modification_cleaning(ress, v)
        new_list = apply_modifications(old_order, ress)
        return new_list


def get_list(order_list):
    print(order_list)
    print("You want to edit something in your list ?")


