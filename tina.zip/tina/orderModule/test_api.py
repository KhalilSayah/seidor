import requests

# Specify the URL of the FastAPI endpoint
url = "http://localhost:8000/order/"

# Path to the audio file you want to upload
audio_file_path = "Sami.m4a"

# Open the audio file in binary mode
with open(audio_file_path, "rb") as f:
    # Prepare the file data to be sent as multipart/form-data
    files = {"file": (audio_file_path, f, "audio/wav")}

    # Send a POST request to the FastAPI endpoint with the audio file
    response = requests.post(url, files=files)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    # Print the response content (cleaned order data)
    print(response.json())
else:
    # Print an error message if the request failed
    print("Error:", response.text)
