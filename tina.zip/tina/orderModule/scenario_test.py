import requests

def init_conversation():
    print("Hello ! i'm Tina i'm here to help you in your order process, let's start, let me hear your voice :D")
    # Wait for the audio of the order

def create_order(input):
    url = "http://localhost:8000/order/"
    with open(input, "rb") as f:
        files = {"file": (input, f, "audio/wav")}
        response = requests.post(url, files=files)
        if response.status_code == 200:
            order_list = response.json()
            print("You want to add something else ?")
            return order_list
        else:
            print("Error:", response.text)



def update_order(input, order_list):
    url = "http://localhost:8000/updateorder/"
    data = {'old_order': order_list}
    print("################# Data ###############")
    print(data)
    with open(input, "rb") as f:
        files = {"file": (input, f, "audio/wav")}
        response = requests.post(url, files=files, data=data)
        print("################# Response ###############")
        print(response)
        if response.status_code == 200:
            order_list = response.json()
            print("You want to add something else ?")
            return order_list
        else:
            print("Error:", response.text)




def main():
    init_conversation()
    print("################# INPUT1 ###############")
    input1 = "poc/data/voice/Sami.m4a" #Passer une commande
    order_list = create_order(input1)

    print("################# INPUT2 ###############")
    input2 = "poc/data/voice/Input2.m4a" #Dire oui, je veux ajouter un produit
    order_list = update_order(input2, order_list=order_list)
    print(order_list)

    print("################# INPUT3 ###############")
    input3 = "poc/data/voice/Input4.m4a"# Dire non, c'est bon je veux plus ajouter
    order_list = update_order(input3, order_list=order_list)
'''
    print("################# INPUT4 ###############")
    input4 = "poc/data/voice/Input4.m4a" #Oui je fait un changement
    order_list = update_order(input4, order_list=order_list)

    print("################# INPUT5 ###############")
    input5 = "poc/data/voice/Input5.m4a" #dire non au changement

'''
'''
def check_missing_data(order_list):
    return True
    '''

main()