from flask import Flask, render_template, request
from datetime import datetime
import requests

app = Flask(__name__)

def create_order(input):
    url = "http://localhost:8000/order/"
    with open(input, "rb") as f:
        files = {"file": (input, f, "audio/wav")}
        response = requests.post(url, files=files)
        if response.status_code == 200:
            order_list = response.json()
            print("You want to add something else ?")
            return order_list
        else:
            print("Error:", response.text)



def update_order(input, order_list):
    url = "http://localhost:8000/updateorder/"
    data = {'old_order': order_list}
    print("################# Data ###############")
    print(data)
    with open(input, "rb") as f:
        files = {"file": (input, f, "audio/wav")}

    response = requests.post(url, files=files, data=data)
    print("################# Response ###############")
    print(response)
    if response.status_code == 200:
        order_list = response.json()
        print("You want to add something else ?")
        return order_list
    else:
        print("Error:", response.text)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/save_audio', methods=['POST'])
def save_audio():
    try:
        audio = request.files['audio']
        recordings_count = int(request.form['recordingsCount'])
        # Générer un nom de fichier unique en fonction de l'heure actuelle
        filename = f"recording_{datetime.now().strftime('%Y%m%d%H%M%S')}.mp3"
        audio.save(f'uploads/{filename}')

        if recordings_count == 1:
            print("NEED TO MAKE API CALL")
            response = create_order(f'uploads/{filename}')
            return f"Theirs your order list{response}, You want to add something else ?", 200
        else:
            order_list = [
                {'id': '1', 'name': 'DEXACORTONE', 'quantity': '4', 'type': 'packs of milliliters'},
                {'id': '2', 'name': 'VERSICAN PLUS DHPPIL', 'quantity': '2', 'type': 'bottles of 16 c'}
            ]
            response = update_order(f'uploads/{filename}', order_list=order_list)
            return response

    except Exception as e:
        return f'Error saving audio: {str(e)}', 500

if __name__ == "__main__":
    app.run(debug=True)