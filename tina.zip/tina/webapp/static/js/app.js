document.getElementById("startRecording").addEventListener("click", initFunction);
        let isRecording = document.getElementById("isRecording");
        let audioChunks = [];
        let recordings = 0; // Counter for recordings

        function initFunction() {
            isRecording.textContent = "Recording...";
            recordings++; // Increment recording counter for unique file names

            async function getUserMedia(constraints) {
                if (navigator.mediaDevices) {
                    return navigator.mediaDevices.getUserMedia(constraints);
                }
                // Rest of the code remains the same
            }

            function handlerFunction(stream) {
                rec = new MediaRecorder(stream);
                rec.start();
                rec.ondataavailable = (e) => {
                    audioChunks.push(e.data);
                };
            }

            function startusingBrowserMicrophone(boolean) {
                getUserMedia({ audio: boolean }).then((stream) => {
                    handlerFunction(stream);
                });
            }

            startusingBrowserMicrophone(true);

            document.getElementById("stopRecording").addEventListener("click", (e) => {
                rec.stop();
                isRecording.textContent = "Click start button to record";
                rec.onstop = () => {
                    let blob = new Blob(audioChunks, { type: "audio/mpeg" });
                    let audioUrl = URL.createObjectURL(blob);
                    let audioElement = document.createElement("audio"); // Create new audio element
                    audioElement.src = audioUrl;
                    audioElement.controls = true;
                    document.getElementById("audioElements").appendChild(audioElement); // Append audio element to container

                    let formData = new FormData();
                    formData.append('audio', blob, 'recording_' + recordings + '.mp3'); // Unique file name for each recording
                    fetch('/save_audio', {
                        method: 'POST',
                        body: formData
                    }).then(response => {
                        if (response.ok) {
                            console.log('Audio saved successfully');
                        } else {
                            console.error('Failed to save audio');
                        }
                    }).catch(error => {
                        console.error('Error while saving audio:', error);
                    });

                    // Reset variables for next recording
                    audioChunks = [];
                };
            });
        }